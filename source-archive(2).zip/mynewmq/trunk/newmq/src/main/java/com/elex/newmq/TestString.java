package com.elex.newmq;

public class TestString {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "newmq.12345";
		String[] re = str.split("\\.");
		
	}

}
